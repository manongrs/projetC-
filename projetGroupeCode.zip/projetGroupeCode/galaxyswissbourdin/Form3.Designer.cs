﻿namespace galaxyswissbourdin
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.ModifBudgetU = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.ModifPrimeU = new System.Windows.Forms.TextBox();
            this.ModifObjectifU = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.modifLoginU = new System.Windows.Forms.TextBox();
            this.textBoxLoginmodifU = new System.Windows.Forms.TextBox();
            this.buttonEnregistrerModifU = new System.Windows.Forms.Button();
            this.comboBoxModifUtilisateur = new System.Windows.Forms.ComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBoxSuppUtilisateur = new System.Windows.Forms.ComboBox();
            this.buttonSupprimerUtilisateur = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.budgettext = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.primetext = new System.Windows.Forms.TextBox();
            this.nivText = new System.Windows.Forms.TextBox();
            this.objtext = new System.Windows.Forms.TextBox();
            this.prenomtext = new System.Windows.Forms.TextBox();
            this.identitetext = new System.Windows.Forms.TextBox();
            this.nomtext = new System.Windows.Forms.TextBox();
            this.Mattext = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.MdpText = new System.Windows.Forms.TextBox();
            this.loginText = new System.Windows.Forms.TextBox();
            this.buttonEnregUser = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBoxMdp = new System.Windows.Forms.TextBox();
            this.textBoxLogin = new System.Windows.Forms.TextBox();
            this.textBoxNivHabilitation = new System.Windows.Forms.TextBox();
            this.textBoxPrenom = new System.Windows.Forms.TextBox();
            this.textBoxIdentite = new System.Windows.Forms.TextBox();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.textBoxMatricule = new System.Windows.Forms.TextBox();
            this.buttonEnregPersonnel = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.buttonEnregistrerModifT = new System.Windows.Forms.Button();
            this.ModifFormation = new System.Windows.Forms.TextBox();
            this.ModifNivInterv = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.ModifMDP = new System.Windows.Forms.TextBox();
            this.ModifLogin = new System.Windows.Forms.TextBox();
            this.comboBoxTechnicienModif = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBoxTechnicienSupp = new System.Windows.Forms.ComboBox();
            this.buttonSupprimerTechnicien = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.formation = new System.Windows.Forms.TextBox();
            this.Nivhabili = new System.Windows.Forms.TextBox();
            this.nivinterv = new System.Windows.Forms.TextBox();
            this.Prenom = new System.Windows.Forms.TextBox();
            this.Identite = new System.Windows.Forms.TextBox();
            this.Nom = new System.Windows.Forms.TextBox();
            this.Matricule = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.mdp = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxMat = new System.Windows.Forms.ComboBox();
            this.supprimerMat = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.AfficherDmat = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxIdPersonnel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxMemoire = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxProcesseur = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxDateAchat = new System.Windows.Forms.TextBox();
            this.textBoxGarantie = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.enregMateriel = new System.Windows.Forms.Button();
            this.textBoxFournisseur = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxDisque = new System.Windows.Forms.TextBox();
            this.textBoxAffectation = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxModifEtatDemande = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonEnregModifEtat = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.TextBoxTypePriseEnCharge = new System.Windows.Forms.TextBox();
            this.textBoxetatIncident = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.textIdMat2 = new System.Windows.Forms.TextBox();
            this.textIdPers2 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.enregIncident = new System.Windows.Forms.Button();
            this.textUtilisateur = new System.Windows.Forms.TextBox();
            this.textTicket = new System.Windows.Forms.TextBox();
            this.textObjet = new System.Windows.Forms.TextBox();
            this.textPoste = new System.Windows.Forms.TextBox();
            this.textNivUrg = new System.Windows.Forms.TextBox();
            this.textHeure2 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabPage5.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox13);
            this.tabPage5.Controls.Add(this.groupBox11);
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1233, 419);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.ModifBudgetU);
            this.groupBox13.Controls.Add(this.label43);
            this.groupBox13.Controls.Add(this.ModifPrimeU);
            this.groupBox13.Controls.Add(this.ModifObjectifU);
            this.groupBox13.Controls.Add(this.label44);
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.label71);
            this.groupBox13.Controls.Add(this.label73);
            this.groupBox13.Controls.Add(this.modifLoginU);
            this.groupBox13.Controls.Add(this.textBoxLoginmodifU);
            this.groupBox13.Controls.Add(this.buttonEnregistrerModifU);
            this.groupBox13.Controls.Add(this.comboBoxModifUtilisateur);
            this.groupBox13.Controls.Add(this.label72);
            this.groupBox13.Location = new System.Drawing.Point(572, 6);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(416, 395);
            this.groupBox13.TabIndex = 65;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Modification d\'un Utilisateur:";
            // 
            // ModifBudgetU
            // 
            this.ModifBudgetU.Location = new System.Drawing.Point(168, 309);
            this.ModifBudgetU.Name = "ModifBudgetU";
            this.ModifBudgetU.Size = new System.Drawing.Size(100, 22);
            this.ModifBudgetU.TabIndex = 52;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(73, 309);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(56, 16);
            this.label43.TabIndex = 51;
            this.label43.Text = "Budget: ";
            // 
            // ModifPrimeU
            // 
            this.ModifPrimeU.Location = new System.Drawing.Point(168, 254);
            this.ModifPrimeU.Name = "ModifPrimeU";
            this.ModifPrimeU.Size = new System.Drawing.Size(100, 22);
            this.ModifPrimeU.TabIndex = 50;
            // 
            // ModifObjectifU
            // 
            this.ModifObjectifU.Location = new System.Drawing.Point(198, 209);
            this.ModifObjectifU.Name = "ModifObjectifU";
            this.ModifObjectifU.Size = new System.Drawing.Size(100, 22);
            this.ModifObjectifU.TabIndex = 49;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(60, 124);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(49, 16);
            this.label44.TabIndex = 48;
            this.label44.Text = "Login : ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(31, 166);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(98, 16);
            this.label45.TabIndex = 47;
            this.label45.Text = "Mot de passe : ";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(77, 254);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(47, 16);
            this.label71.TabIndex = 46;
            this.label71.Text = "prime: ";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(31, 209);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(58, 16);
            this.label73.TabIndex = 45;
            this.label73.Text = "Objectif :";
            // 
            // modifLoginU
            // 
            this.modifLoginU.Location = new System.Drawing.Point(135, 163);
            this.modifLoginU.Name = "modifLoginU";
            this.modifLoginU.Size = new System.Drawing.Size(100, 22);
            this.modifLoginU.TabIndex = 44;
            // 
            // textBoxLoginmodifU
            // 
            this.textBoxLoginmodifU.Location = new System.Drawing.Point(117, 118);
            this.textBoxLoginmodifU.Name = "textBoxLoginmodifU";
            this.textBoxLoginmodifU.Size = new System.Drawing.Size(100, 22);
            this.textBoxLoginmodifU.TabIndex = 43;
            // 
            // buttonEnregistrerModifU
            // 
            this.buttonEnregistrerModifU.Location = new System.Drawing.Point(97, 355);
            this.buttonEnregistrerModifU.Name = "buttonEnregistrerModifU";
            this.buttonEnregistrerModifU.Size = new System.Drawing.Size(212, 23);
            this.buttonEnregistrerModifU.TabIndex = 42;
            this.buttonEnregistrerModifU.Text = "Enregistrer Modif Utilisateur";
            this.buttonEnregistrerModifU.UseVisualStyleBackColor = true;
            // 
            // comboBoxModifUtilisateur
            // 
            this.comboBoxModifUtilisateur.FormattingEnabled = true;
            this.comboBoxModifUtilisateur.Location = new System.Drawing.Point(24, 68);
            this.comboBoxModifUtilisateur.Name = "comboBoxModifUtilisateur";
            this.comboBoxModifUtilisateur.Size = new System.Drawing.Size(121, 24);
            this.comboBoxModifUtilisateur.TabIndex = 3;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(21, 34);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(164, 16);
            this.label72.TabIndex = 2;
            this.label72.Text = "Sélectionner un Utilisateur:";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label24);
            this.groupBox11.Controls.Add(this.comboBoxSuppUtilisateur);
            this.groupBox11.Controls.Add(this.buttonSupprimerUtilisateur);
            this.groupBox11.Location = new System.Drawing.Point(1017, 100);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(210, 202);
            this.groupBox11.TabIndex = 64;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Suppression d\'un Utilisateur:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 49);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(165, 16);
            this.label24.TabIndex = 57;
            this.label24.Text = "sélectionner un Utilisateur :";
            // 
            // comboBoxSuppUtilisateur
            // 
            this.comboBoxSuppUtilisateur.FormattingEnabled = true;
            this.comboBoxSuppUtilisateur.Location = new System.Drawing.Point(10, 102);
            this.comboBoxSuppUtilisateur.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSuppUtilisateur.Name = "comboBoxSuppUtilisateur";
            this.comboBoxSuppUtilisateur.Size = new System.Drawing.Size(160, 24);
            this.comboBoxSuppUtilisateur.TabIndex = 58;
            // 
            // buttonSupprimerUtilisateur
            // 
            this.buttonSupprimerUtilisateur.Location = new System.Drawing.Point(98, 154);
            this.buttonSupprimerUtilisateur.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSupprimerUtilisateur.Name = "buttonSupprimerUtilisateur";
            this.buttonSupprimerUtilisateur.Size = new System.Drawing.Size(100, 28);
            this.buttonSupprimerUtilisateur.TabIndex = 59;
            this.buttonSupprimerUtilisateur.Text = "Suprimer";
            this.buttonSupprimerUtilisateur.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.budgettext);
            this.groupBox10.Controls.Add(this.label);
            this.groupBox10.Controls.Add(this.primetext);
            this.groupBox10.Controls.Add(this.nivText);
            this.groupBox10.Controls.Add(this.objtext);
            this.groupBox10.Controls.Add(this.prenomtext);
            this.groupBox10.Controls.Add(this.identitetext);
            this.groupBox10.Controls.Add(this.nomtext);
            this.groupBox10.Controls.Add(this.Mattext);
            this.groupBox10.Controls.Add(this.label46);
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.label49);
            this.groupBox10.Controls.Add(this.label51);
            this.groupBox10.Controls.Add(this.label52);
            this.groupBox10.Controls.Add(this.label53);
            this.groupBox10.Controls.Add(this.label54);
            this.groupBox10.Controls.Add(this.label55);
            this.groupBox10.Controls.Add(this.MdpText);
            this.groupBox10.Controls.Add(this.loginText);
            this.groupBox10.Controls.Add(this.buttonEnregUser);
            this.groupBox10.Location = new System.Drawing.Point(39, 42);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(514, 330);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Ajout d\'un Utilisateur:";
            // 
            // budgettext
            // 
            this.budgettext.Location = new System.Drawing.Point(376, 233);
            this.budgettext.Name = "budgettext";
            this.budgettext.Size = new System.Drawing.Size(100, 22);
            this.budgettext.TabIndex = 35;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(281, 233);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(56, 16);
            this.label.TabIndex = 34;
            this.label.Text = "Budget: ";
            // 
            // primetext
            // 
            this.primetext.Location = new System.Drawing.Point(376, 178);
            this.primetext.Name = "primetext";
            this.primetext.Size = new System.Drawing.Size(100, 22);
            this.primetext.TabIndex = 33;
            // 
            // nivText
            // 
            this.nivText.Location = new System.Drawing.Point(126, 172);
            this.nivText.Name = "nivText";
            this.nivText.Size = new System.Drawing.Size(100, 22);
            this.nivText.TabIndex = 32;
            // 
            // objtext
            // 
            this.objtext.Location = new System.Drawing.Point(406, 133);
            this.objtext.Name = "objtext";
            this.objtext.Size = new System.Drawing.Size(100, 22);
            this.objtext.TabIndex = 31;
            // 
            // prenomtext
            // 
            this.prenomtext.Location = new System.Drawing.Point(118, 233);
            this.prenomtext.Name = "prenomtext";
            this.prenomtext.Size = new System.Drawing.Size(100, 22);
            this.prenomtext.TabIndex = 30;
            // 
            // identitetext
            // 
            this.identitetext.Location = new System.Drawing.Point(98, 133);
            this.identitetext.Name = "identitetext";
            this.identitetext.Size = new System.Drawing.Size(100, 22);
            this.identitetext.TabIndex = 28;
            // 
            // nomtext
            // 
            this.nomtext.Location = new System.Drawing.Point(98, 87);
            this.nomtext.Name = "nomtext";
            this.nomtext.Size = new System.Drawing.Size(100, 22);
            this.nomtext.TabIndex = 27;
            // 
            // Mattext
            // 
            this.Mattext.Location = new System.Drawing.Point(118, 45);
            this.Mattext.Name = "Mattext";
            this.Mattext.Size = new System.Drawing.Size(100, 22);
            this.Mattext.TabIndex = 26;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(268, 48);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(49, 16);
            this.label46.TabIndex = 25;
            this.label46.Text = "Login : ";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(239, 90);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(98, 16);
            this.label47.TabIndex = 24;
            this.label47.Text = "Mot de passe : ";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(17, 178);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(103, 16);
            this.label48.TabIndex = 23;
            this.label48.Text = "Niv Habilitation :";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(37, 236);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(60, 16);
            this.label49.TabIndex = 22;
            this.label49.Text = "Prenom :";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(30, 133);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(56, 16);
            this.label51.TabIndex = 20;
            this.label51.Text = "Identite :";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(30, 90);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(42, 16);
            this.label52.TabIndex = 19;
            this.label52.Text = "Nom :";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(30, 48);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(67, 16);
            this.label53.TabIndex = 18;
            this.label53.Text = "Matricule :";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(285, 178);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(47, 16);
            this.label54.TabIndex = 4;
            this.label54.Text = "prime: ";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(239, 133);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(58, 16);
            this.label55.TabIndex = 3;
            this.label55.Text = "Objectif :";
            // 
            // MdpText
            // 
            this.MdpText.Location = new System.Drawing.Point(343, 87);
            this.MdpText.Name = "MdpText";
            this.MdpText.Size = new System.Drawing.Size(100, 22);
            this.MdpText.TabIndex = 2;
            // 
            // loginText
            // 
            this.loginText.Location = new System.Drawing.Point(325, 42);
            this.loginText.Name = "loginText";
            this.loginText.Size = new System.Drawing.Size(100, 22);
            this.loginText.TabIndex = 1;
            // 
            // buttonEnregUser
            // 
            this.buttonEnregUser.Location = new System.Drawing.Point(288, 281);
            this.buttonEnregUser.Name = "buttonEnregUser";
            this.buttonEnregUser.Size = new System.Drawing.Size(189, 23);
            this.buttonEnregUser.TabIndex = 0;
            this.buttonEnregUser.Text = "Enregistrer un Utilisateur";
            this.buttonEnregUser.UseVisualStyleBackColor = true;
            this.buttonEnregUser.Click += new System.EventHandler(this.buttonEnregUser_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox8);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1233, 419);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBoxMdp);
            this.groupBox8.Controls.Add(this.textBoxLogin);
            this.groupBox8.Controls.Add(this.textBoxNivHabilitation);
            this.groupBox8.Controls.Add(this.textBoxPrenom);
            this.groupBox8.Controls.Add(this.textBoxIdentite);
            this.groupBox8.Controls.Add(this.textBoxNom);
            this.groupBox8.Controls.Add(this.textBoxMatricule);
            this.groupBox8.Controls.Add(this.buttonEnregPersonnel);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.label6);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Location = new System.Drawing.Point(36, 35);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(511, 339);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Ajout membre du personnel:";
            // 
            // textBoxMdp
            // 
            this.textBoxMdp.Location = new System.Drawing.Point(358, 204);
            this.textBoxMdp.Name = "textBoxMdp";
            this.textBoxMdp.Size = new System.Drawing.Size(100, 22);
            this.textBoxMdp.TabIndex = 17;
            // 
            // textBoxLogin
            // 
            this.textBoxLogin.Location = new System.Drawing.Point(106, 201);
            this.textBoxLogin.Name = "textBoxLogin";
            this.textBoxLogin.Size = new System.Drawing.Size(100, 22);
            this.textBoxLogin.TabIndex = 16;
            // 
            // textBoxNivHabilitation
            // 
            this.textBoxNivHabilitation.Location = new System.Drawing.Point(367, 150);
            this.textBoxNivHabilitation.Name = "textBoxNivHabilitation";
            this.textBoxNivHabilitation.Size = new System.Drawing.Size(100, 22);
            this.textBoxNivHabilitation.TabIndex = 15;
            // 
            // textBoxPrenom
            // 
            this.textBoxPrenom.Location = new System.Drawing.Point(367, 96);
            this.textBoxPrenom.Name = "textBoxPrenom";
            this.textBoxPrenom.Size = new System.Drawing.Size(100, 22);
            this.textBoxPrenom.TabIndex = 14;
            // 
            // textBoxIdentite
            // 
            this.textBoxIdentite.Location = new System.Drawing.Point(106, 151);
            this.textBoxIdentite.Name = "textBoxIdentite";
            this.textBoxIdentite.Size = new System.Drawing.Size(100, 22);
            this.textBoxIdentite.TabIndex = 12;
            // 
            // textBoxNom
            // 
            this.textBoxNom.Location = new System.Drawing.Point(106, 97);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(100, 22);
            this.textBoxNom.TabIndex = 11;
            // 
            // textBoxMatricule
            // 
            this.textBoxMatricule.Location = new System.Drawing.Point(106, 38);
            this.textBoxMatricule.Name = "textBoxMatricule";
            this.textBoxMatricule.Size = new System.Drawing.Size(100, 22);
            this.textBoxMatricule.TabIndex = 10;
            // 
            // buttonEnregPersonnel
            // 
            this.buttonEnregPersonnel.Location = new System.Drawing.Point(86, 275);
            this.buttonEnregPersonnel.Name = "buttonEnregPersonnel";
            this.buttonEnregPersonnel.Size = new System.Drawing.Size(254, 23);
            this.buttonEnregPersonnel.TabIndex = 9;
            this.buttonEnregPersonnel.Text = "Enregistrer Membre du Personnel";
            this.buttonEnregPersonnel.UseVisualStyleBackColor = true;
            this.buttonEnregPersonnel.Click += new System.EventHandler(this.buttonEnregPersonnel_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(14, 201);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(49, 16);
            this.label36.TabIndex = 8;
            this.label36.Text = "Login : ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(243, 204);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(98, 16);
            this.label35.TabIndex = 7;
            this.label35.Text = "Mot de passe : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(237, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 16);
            this.label14.TabIndex = 6;
            this.label14.Text = "Niv Habilitation :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(281, 97);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 16);
            this.label11.TabIndex = 5;
            this.label11.Text = "Prenom :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Identite :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Nom :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Matricule :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox12);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1233, 419);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.buttonEnregistrerModifT);
            this.groupBox12.Controls.Add(this.ModifFormation);
            this.groupBox12.Controls.Add(this.ModifNivInterv);
            this.groupBox12.Controls.Add(this.label39);
            this.groupBox12.Controls.Add(this.label40);
            this.groupBox12.Controls.Add(this.label41);
            this.groupBox12.Controls.Add(this.label42);
            this.groupBox12.Controls.Add(this.ModifMDP);
            this.groupBox12.Controls.Add(this.ModifLogin);
            this.groupBox12.Controls.Add(this.comboBoxTechnicienModif);
            this.groupBox12.Controls.Add(this.label38);
            this.groupBox12.Location = new System.Drawing.Point(567, 42);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(416, 353);
            this.groupBox12.TabIndex = 64;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Modification d\'un Technicien:";
            // 
            // buttonEnregistrerModifT
            // 
            this.buttonEnregistrerModifT.Location = new System.Drawing.Point(92, 296);
            this.buttonEnregistrerModifT.Name = "buttonEnregistrerModifT";
            this.buttonEnregistrerModifT.Size = new System.Drawing.Size(212, 23);
            this.buttonEnregistrerModifT.TabIndex = 42;
            this.buttonEnregistrerModifT.Text = "Enregistrer Modif Technicien";
            this.buttonEnregistrerModifT.UseVisualStyleBackColor = true;
            // 
            // ModifFormation
            // 
            this.ModifFormation.Location = new System.Drawing.Point(143, 239);
            this.ModifFormation.Name = "ModifFormation";
            this.ModifFormation.Size = new System.Drawing.Size(100, 22);
            this.ModifFormation.TabIndex = 41;
            // 
            // ModifNivInterv
            // 
            this.ModifNivInterv.Location = new System.Drawing.Point(173, 194);
            this.ModifNivInterv.Name = "ModifNivInterv";
            this.ModifNivInterv.Size = new System.Drawing.Size(100, 22);
            this.ModifNivInterv.TabIndex = 40;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(35, 109);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(49, 16);
            this.label39.TabIndex = 39;
            this.label39.Text = "Login : ";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 151);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(98, 16);
            this.label40.TabIndex = 38;
            this.label40.Text = "Mot de passe : ";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(52, 239);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 16);
            this.label41.TabIndex = 37;
            this.label41.Text = "formation :";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 194);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(138, 16);
            this.label42.TabIndex = 36;
            this.label42.Text = "Niveau d\'intervention :";
            // 
            // ModifMDP
            // 
            this.ModifMDP.Location = new System.Drawing.Point(110, 148);
            this.ModifMDP.Name = "ModifMDP";
            this.ModifMDP.Size = new System.Drawing.Size(100, 22);
            this.ModifMDP.TabIndex = 35;
            // 
            // ModifLogin
            // 
            this.ModifLogin.Location = new System.Drawing.Point(92, 103);
            this.ModifLogin.Name = "ModifLogin";
            this.ModifLogin.Size = new System.Drawing.Size(100, 22);
            this.ModifLogin.TabIndex = 34;
            // 
            // comboBoxTechnicienModif
            // 
            this.comboBoxTechnicienModif.FormattingEnabled = true;
            this.comboBoxTechnicienModif.Location = new System.Drawing.Point(24, 68);
            this.comboBoxTechnicienModif.Name = "comboBoxTechnicienModif";
            this.comboBoxTechnicienModif.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTechnicienModif.TabIndex = 3;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(21, 34);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(171, 16);
            this.label38.TabIndex = 2;
            this.label38.Text = "Sélectionner un Technicien:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label7);
            this.groupBox9.Controls.Add(this.comboBoxTechnicienSupp);
            this.groupBox9.Controls.Add(this.buttonSupprimerTechnicien);
            this.groupBox9.Location = new System.Drawing.Point(1003, 91);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(212, 202);
            this.groupBox9.TabIndex = 63;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Suppression d\'un Technicien:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 49);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 16);
            this.label7.TabIndex = 57;
            this.label7.Text = "sélectionner un technicien :";
            // 
            // comboBoxTechnicienSupp
            // 
            this.comboBoxTechnicienSupp.FormattingEnabled = true;
            this.comboBoxTechnicienSupp.Location = new System.Drawing.Point(10, 102);
            this.comboBoxTechnicienSupp.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxTechnicienSupp.Name = "comboBoxTechnicienSupp";
            this.comboBoxTechnicienSupp.Size = new System.Drawing.Size(160, 24);
            this.comboBoxTechnicienSupp.TabIndex = 58;
            // 
            // buttonSupprimerTechnicien
            // 
            this.buttonSupprimerTechnicien.Location = new System.Drawing.Point(98, 154);
            this.buttonSupprimerTechnicien.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSupprimerTechnicien.Name = "buttonSupprimerTechnicien";
            this.buttonSupprimerTechnicien.Size = new System.Drawing.Size(100, 28);
            this.buttonSupprimerTechnicien.TabIndex = 59;
            this.buttonSupprimerTechnicien.Text = "Suprimer";
            this.buttonSupprimerTechnicien.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.formation);
            this.groupBox7.Controls.Add(this.Nivhabili);
            this.groupBox7.Controls.Add(this.nivinterv);
            this.groupBox7.Controls.Add(this.Prenom);
            this.groupBox7.Controls.Add(this.Identite);
            this.groupBox7.Controls.Add(this.Nom);
            this.groupBox7.Controls.Add(this.Matricule);
            this.groupBox7.Controls.Add(this.label61);
            this.groupBox7.Controls.Add(this.label62);
            this.groupBox7.Controls.Add(this.label63);
            this.groupBox7.Controls.Add(this.label64);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Controls.Add(this.label67);
            this.groupBox7.Controls.Add(this.label68);
            this.groupBox7.Controls.Add(this.label69);
            this.groupBox7.Controls.Add(this.label70);
            this.groupBox7.Controls.Add(this.mdp);
            this.groupBox7.Controls.Add(this.login);
            this.groupBox7.Controls.Add(this.button2);
            this.groupBox7.Location = new System.Drawing.Point(23, 31);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(517, 330);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Ajout d\'un Technicien :";
            // 
            // formation
            // 
            this.formation.Location = new System.Drawing.Point(376, 178);
            this.formation.Name = "formation";
            this.formation.Size = new System.Drawing.Size(100, 22);
            this.formation.TabIndex = 33;
            // 
            // Nivhabili
            // 
            this.Nivhabili.Location = new System.Drawing.Point(126, 172);
            this.Nivhabili.Name = "Nivhabili";
            this.Nivhabili.Size = new System.Drawing.Size(100, 22);
            this.Nivhabili.TabIndex = 32;
            // 
            // nivinterv
            // 
            this.nivinterv.Location = new System.Drawing.Point(406, 133);
            this.nivinterv.Name = "nivinterv";
            this.nivinterv.Size = new System.Drawing.Size(100, 22);
            this.nivinterv.TabIndex = 31;
            // 
            // Prenom
            // 
            this.Prenom.Location = new System.Drawing.Point(98, 223);
            this.Prenom.Name = "Prenom";
            this.Prenom.Size = new System.Drawing.Size(100, 22);
            this.Prenom.TabIndex = 30;
            // 
            // Identite
            // 
            this.Identite.Location = new System.Drawing.Point(98, 133);
            this.Identite.Name = "Identite";
            this.Identite.Size = new System.Drawing.Size(100, 22);
            this.Identite.TabIndex = 28;
            // 
            // Nom
            // 
            this.Nom.Location = new System.Drawing.Point(98, 87);
            this.Nom.Name = "Nom";
            this.Nom.Size = new System.Drawing.Size(100, 22);
            this.Nom.TabIndex = 27;
            // 
            // Matricule
            // 
            this.Matricule.Location = new System.Drawing.Point(118, 45);
            this.Matricule.Name = "Matricule";
            this.Matricule.Size = new System.Drawing.Size(100, 22);
            this.Matricule.TabIndex = 26;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(268, 48);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(49, 16);
            this.label61.TabIndex = 25;
            this.label61.Text = "Login : ";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(239, 90);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(98, 16);
            this.label62.TabIndex = 24;
            this.label62.Text = "Mot de passe : ";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(17, 178);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(103, 16);
            this.label63.TabIndex = 23;
            this.label63.Text = "Niv Habilitation :";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(30, 226);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(60, 16);
            this.label64.TabIndex = 22;
            this.label64.Text = "Prenom :";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(30, 133);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(56, 16);
            this.label66.TabIndex = 20;
            this.label66.Text = "Identite :";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(30, 90);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(42, 16);
            this.label67.TabIndex = 19;
            this.label67.Text = "Nom :";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(30, 48);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(67, 16);
            this.label68.TabIndex = 18;
            this.label68.Text = "Matricule :";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(285, 178);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(68, 16);
            this.label69.TabIndex = 4;
            this.label69.Text = "formation :";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(239, 133);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(138, 16);
            this.label70.TabIndex = 3;
            this.label70.Text = "Niveau d\'intervention :";
            // 
            // mdp
            // 
            this.mdp.Location = new System.Drawing.Point(343, 87);
            this.mdp.Name = "mdp";
            this.mdp.Size = new System.Drawing.Size(100, 22);
            this.mdp.TabIndex = 2;
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(325, 42);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(100, 22);
            this.login.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(288, 281);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(189, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Enregistrer un technicien";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1233, 419);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabpage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.comboBoxMat);
            this.groupBox4.Controls.Add(this.supprimerMat);
            this.groupBox4.Location = new System.Drawing.Point(848, 43);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(296, 202);
            this.groupBox4.TabIndex = 62;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Suppression d\'un Matériel:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 49);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(154, 16);
            this.label15.TabIndex = 57;
            this.label15.Text = "sélectionner un matériel :";
            // 
            // comboBoxMat
            // 
            this.comboBoxMat.FormattingEnabled = true;
            this.comboBoxMat.Location = new System.Drawing.Point(10, 102);
            this.comboBoxMat.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxMat.Name = "comboBoxMat";
            this.comboBoxMat.Size = new System.Drawing.Size(160, 24);
            this.comboBoxMat.TabIndex = 58;
            // 
            // supprimerMat
            // 
            this.supprimerMat.Location = new System.Drawing.Point(98, 154);
            this.supprimerMat.Margin = new System.Windows.Forms.Padding(4);
            this.supprimerMat.Name = "supprimerMat";
            this.supprimerMat.Size = new System.Drawing.Size(100, 28);
            this.supprimerMat.TabIndex = 59;
            this.supprimerMat.Text = "Suprimer";
            this.supprimerMat.UseVisualStyleBackColor = true;
            this.supprimerMat.Click += new System.EventHandler(this.supprimerMat_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.AfficherDmat);
            this.groupBox3.Controls.Add(this.listBox2);
            this.groupBox3.Location = new System.Drawing.Point(497, 31);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(306, 361);
            this.groupBox3.TabIndex = 61;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Consultation matériel:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 61);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(148, 16);
            this.label12.TabIndex = 51;
            this.label12.Text = "sélectionner un matériel";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(10, 94);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(160, 24);
            this.comboBox4.TabIndex = 52;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 138);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 16);
            this.label13.TabIndex = 53;
            this.label13.Text = "afficher détails";
            // 
            // AfficherDmat
            // 
            this.AfficherDmat.Location = new System.Drawing.Point(10, 165);
            this.AfficherDmat.Margin = new System.Windows.Forms.Padding(4);
            this.AfficherDmat.Name = "AfficherDmat";
            this.AfficherDmat.Size = new System.Drawing.Size(100, 28);
            this.AfficherDmat.TabIndex = 54;
            this.AfficherDmat.Text = "afficher";
            this.AfficherDmat.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 16;
            this.listBox2.Location = new System.Drawing.Point(11, 220);
            this.listBox2.Margin = new System.Windows.Forms.Padding(4);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(159, 116);
            this.listBox2.TabIndex = 55;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxIdPersonnel);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.textBoxMemoire);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.textBoxProcesseur);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.textBoxDateAchat);
            this.groupBox2.Controls.Add(this.textBoxGarantie);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.enregMateriel);
            this.groupBox2.Controls.Add(this.textBoxFournisseur);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.textBoxDisque);
            this.groupBox2.Controls.Add(this.textBoxAffectation);
            this.groupBox2.Location = new System.Drawing.Point(31, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(433, 342);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ajout d\'un materiel";
            // 
            // textBoxIdPersonnel
            // 
            this.textBoxIdPersonnel.Location = new System.Drawing.Point(285, 234);
            this.textBoxIdPersonnel.Name = "textBoxIdPersonnel";
            this.textBoxIdPersonnel.Size = new System.Drawing.Size(100, 22);
            this.textBoxIdPersonnel.TabIndex = 51;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(297, 204);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 16);
            this.label20.TabIndex = 50;
            this.label20.Text = "Id Personnel :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 120);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 16);
            this.label23.TabIndex = 32;
            this.label23.Text = "Processeur:";
            // 
            // textBoxMemoire
            // 
            this.textBoxMemoire.Location = new System.Drawing.Point(10, 86);
            this.textBoxMemoire.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMemoire.Name = "textBoxMemoire";
            this.textBoxMemoire.Size = new System.Drawing.Size(132, 22);
            this.textBoxMemoire.TabIndex = 40;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(7, 55);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 16);
            this.label22.TabIndex = 33;
            this.label22.Text = "Mémoire :";
            // 
            // textBoxProcesseur
            // 
            this.textBoxProcesseur.Location = new System.Drawing.Point(10, 140);
            this.textBoxProcesseur.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProcesseur.Name = "textBoxProcesseur";
            this.textBoxProcesseur.Size = new System.Drawing.Size(132, 22);
            this.textBoxProcesseur.TabIndex = 41;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(305, 140);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(56, 16);
            this.label21.TabIndex = 34;
            this.label21.Text = "Disque :";
            // 
            // textBoxDateAchat
            // 
            this.textBoxDateAchat.Location = new System.Drawing.Point(10, 198);
            this.textBoxDateAchat.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxDateAchat.Name = "textBoxDateAchat";
            this.textBoxDateAchat.Size = new System.Drawing.Size(132, 22);
            this.textBoxDateAchat.TabIndex = 42;
            // 
            // textBoxGarantie
            // 
            this.textBoxGarantie.Location = new System.Drawing.Point(10, 254);
            this.textBoxGarantie.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxGarantie.Name = "textBoxGarantie";
            this.textBoxGarantie.Size = new System.Drawing.Size(132, 22);
            this.textBoxGarantie.TabIndex = 43;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 178);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(143, 16);
            this.label19.TabIndex = 36;
            this.label19.Text = "Date d\'achat /location :";
            // 
            // enregMateriel
            // 
            this.enregMateriel.Location = new System.Drawing.Point(285, 299);
            this.enregMateriel.Margin = new System.Windows.Forms.Padding(4);
            this.enregMateriel.Name = "enregMateriel";
            this.enregMateriel.Size = new System.Drawing.Size(100, 28);
            this.enregMateriel.TabIndex = 49;
            this.enregMateriel.Text = "enregistrer";
            this.enregMateriel.UseVisualStyleBackColor = true;
            this.enregMateriel.Click += new System.EventHandler(this.enregMateriel_Click);
            // 
            // textBoxFournisseur
            // 
            this.textBoxFournisseur.Location = new System.Drawing.Point(10, 305);
            this.textBoxFournisseur.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFournisseur.Name = "textBoxFournisseur";
            this.textBoxFournisseur.Size = new System.Drawing.Size(132, 22);
            this.textBoxFournisseur.TabIndex = 44;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(211, 67);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(222, 16);
            this.label16.TabIndex = 48;
            this.label16.Text = "Affectattion d\'un membre personnel :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 232);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 16);
            this.label18.TabIndex = 37;
            this.label18.Text = "Garantie :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 284);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 16);
            this.label17.TabIndex = 38;
            this.label17.Text = "fournisseurs :";
            // 
            // textBoxDisque
            // 
            this.textBoxDisque.Location = new System.Drawing.Point(275, 160);
            this.textBoxDisque.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxDisque.Name = "textBoxDisque";
            this.textBoxDisque.Size = new System.Drawing.Size(132, 22);
            this.textBoxDisque.TabIndex = 46;
            // 
            // textBoxAffectation
            // 
            this.textBoxAffectation.Location = new System.Drawing.Point(275, 99);
            this.textBoxAffectation.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAffectation.Name = "textBoxAffectation";
            this.textBoxAffectation.Size = new System.Drawing.Size(132, 22);
            this.textBoxAffectation.TabIndex = 45;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1233, 419);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBoxModifEtatDemande);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.comboBox2);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.buttonEnregModifEtat);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Location = new System.Drawing.Point(946, 36);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(259, 350);
            this.groupBox6.TabIndex = 78;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Modification état de la demande";
            // 
            // textBoxModifEtatDemande
            // 
            this.textBoxModifEtatDemande.Location = new System.Drawing.Point(31, 220);
            this.textBoxModifEtatDemande.Name = "textBoxModifEtatDemande";
            this.textBoxModifEtatDemande.Size = new System.Drawing.Size(100, 22);
            this.textBoxModifEtatDemande.TabIndex = 78;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(31, 184);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(110, 16);
            this.label59.TabIndex = 77;
            this.label59.Text = "résolue, cloturée)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(28, 151);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(149, 16);
            this.label37.TabIndex = 76;
            this.label37.Text = "(En cours de traitement, ";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(31, 79);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Sélectionner un incident:";
            // 
            // buttonEnregModifEtat
            // 
            this.buttonEnregModifEtat.Location = new System.Drawing.Point(90, 298);
            this.buttonEnregModifEtat.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEnregModifEtat.Name = "buttonEnregModifEtat";
            this.buttonEnregModifEtat.Size = new System.Drawing.Size(100, 28);
            this.buttonEnregModifEtat.TabIndex = 75;
            this.buttonEnregModifEtat.Text = "enregistrer";
            this.buttonEnregModifEtat.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(28, 116);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(129, 16);
            this.label34.TabIndex = 70;
            this.label34.Text = "état de la demande :";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label60);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.comboBox1);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Location = new System.Drawing.Point(561, 18);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(379, 380);
            this.groupBox5.TabIndex = 64;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Consultation des incidents";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(10, 86);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(342, 16);
            this.label60.TabIndex = 39;
            this.label60.Text = "(Afficher avancement incidents déclaré/ses informations)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 25);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 16);
            this.label2.TabIndex = 35;
            this.label2.Text = "Sélection ticket incidents :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(10, 54);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(160, 24);
            this.comboBox1.TabIndex = 36;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(10, 128);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 28);
            this.button1.TabIndex = 37;
            this.button1.Text = "consulter";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(10, 180);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(342, 196);
            this.listBox1.TabIndex = 38;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label58);
            this.groupBox1.Controls.Add(this.label57);
            this.groupBox1.Controls.Add(this.TextBoxTypePriseEnCharge);
            this.groupBox1.Controls.Add(this.textBoxetatIncident);
            this.groupBox1.Controls.Add(this.label56);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.textIdMat2);
            this.groupBox1.Controls.Add(this.textIdPers2);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.enregIncident);
            this.groupBox1.Controls.Add(this.textUtilisateur);
            this.groupBox1.Controls.Add(this.textTicket);
            this.groupBox1.Controls.Add(this.textObjet);
            this.groupBox1.Controls.Add(this.textPoste);
            this.groupBox1.Controls.Add(this.textNivUrg);
            this.groupBox1.Controls.Add(this.textHeure2);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Location = new System.Drawing.Point(26, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(497, 527);
            this.groupBox1.TabIndex = 63;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Déclarer un incident";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(235, 96);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(135, 16);
            this.label25.TabIndex = 83;
            this.label25.Text = "déplacement sur site)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(235, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 16);
            this.label1.TabIndex = 82;
            this.label1.Text = "(Téléphone, Télémaintenance, ";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(238, 65);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(0, 16);
            this.label58.TabIndex = 81;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(232, 36);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(163, 16);
            this.label57.TabIndex = 80;
            this.label57.Text = "Type de Prise en Charge: ";
            // 
            // TextBoxTypePriseEnCharge
            // 
            this.TextBoxTypePriseEnCharge.Location = new System.Drawing.Point(238, 128);
            this.TextBoxTypePriseEnCharge.Name = "TextBoxTypePriseEnCharge";
            this.TextBoxTypePriseEnCharge.Size = new System.Drawing.Size(100, 22);
            this.TextBoxTypePriseEnCharge.TabIndex = 79;
            // 
            // textBoxetatIncident
            // 
            this.textBoxetatIncident.Location = new System.Drawing.Point(235, 191);
            this.textBoxetatIncident.Name = "textBoxetatIncident";
            this.textBoxetatIncident.Size = new System.Drawing.Size(100, 22);
            this.textBoxetatIncident.TabIndex = 78;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(238, 163);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(156, 16);
            this.label56.TabIndex = 77;
            this.label56.Text = "Etat Incident : (enregistré)";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(235, 299);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(75, 16);
            this.label33.TabIndex = 76;
            this.label33.Text = "id Matériel: ";
            // 
            // textIdMat2
            // 
            this.textIdMat2.Location = new System.Drawing.Point(238, 327);
            this.textIdMat2.Name = "textIdMat2";
            this.textIdMat2.Size = new System.Drawing.Size(100, 22);
            this.textIdMat2.TabIndex = 75;
            // 
            // textIdPers2
            // 
            this.textIdPers2.Location = new System.Drawing.Point(235, 262);
            this.textIdPers2.Name = "textIdPers2";
            this.textIdPers2.Size = new System.Drawing.Size(100, 22);
            this.textIdPers2.TabIndex = 74;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(235, 229);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 16);
            this.label32.TabIndex = 73;
            this.label32.Text = "id Personnel:";
            // 
            // enregIncident
            // 
            this.enregIncident.Location = new System.Drawing.Point(39, 368);
            this.enregIncident.Name = "enregIncident";
            this.enregIncident.Size = new System.Drawing.Size(155, 23);
            this.enregIncident.TabIndex = 72;
            this.enregIncident.Text = "Enregistrer ";
            this.enregIncident.UseVisualStyleBackColor = true;
            this.enregIncident.Click += new System.EventHandler(this.enregIncident_Click);
            // 
            // textUtilisateur
            // 
            this.textUtilisateur.Location = new System.Drawing.Point(26, 96);
            this.textUtilisateur.Name = "textUtilisateur";
            this.textUtilisateur.Size = new System.Drawing.Size(100, 22);
            this.textUtilisateur.TabIndex = 71;
            // 
            // textTicket
            // 
            this.textTicket.Location = new System.Drawing.Point(21, 50);
            this.textTicket.Name = "textTicket";
            this.textTicket.Size = new System.Drawing.Size(100, 22);
            this.textTicket.TabIndex = 70;
            // 
            // textObjet
            // 
            this.textObjet.Location = new System.Drawing.Point(26, 147);
            this.textObjet.Name = "textObjet";
            this.textObjet.Size = new System.Drawing.Size(100, 22);
            this.textObjet.TabIndex = 69;
            // 
            // textPoste
            // 
            this.textPoste.Location = new System.Drawing.Point(26, 213);
            this.textPoste.Name = "textPoste";
            this.textPoste.Size = new System.Drawing.Size(100, 22);
            this.textPoste.TabIndex = 68;
            // 
            // textNivUrg
            // 
            this.textNivUrg.Location = new System.Drawing.Point(26, 278);
            this.textNivUrg.Name = "textNivUrg";
            this.textNivUrg.Size = new System.Drawing.Size(100, 22);
            this.textNivUrg.TabIndex = 67;
            // 
            // textHeure2
            // 
            this.textHeure2.Location = new System.Drawing.Point(26, 331);
            this.textHeure2.Name = "textHeure2";
            this.textHeure2.Size = new System.Drawing.Size(100, 22);
            this.textHeure2.TabIndex = 66;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(23, 312);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(50, 16);
            this.label31.TabIndex = 65;
            this.label31.Text = "Heure: ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(23, 249);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(119, 16);
            this.label30.TabIndex = 64;
            this.label30.Text = "Niveau d\'urgence :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(31, 180);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 16);
            this.label27.TabIndex = 63;
            this.label27.Text = "Poste :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 16);
            this.label10.TabIndex = 58;
            this.label10.Text = "ticket incident : ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(23, 128);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(42, 16);
            this.label29.TabIndex = 62;
            this.label29.Text = "Objet:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(18, 75);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(122, 16);
            this.label28.TabIndex = 61;
            this.label28.Text = "utilisateur Emetteur:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(20, 69);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 16);
            this.label26.TabIndex = 59;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(57, -12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 16);
            this.label9.TabIndex = 57;
            this.label9.Text = "Déclarer un incident : ";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1241, 448);
            this.tabControl1.TabIndex = 0;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1469, 571);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.tabPage5.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox budgettext;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox primetext;
        private System.Windows.Forms.TextBox nivText;
        private System.Windows.Forms.TextBox objtext;
        private System.Windows.Forms.TextBox prenomtext;
        private System.Windows.Forms.TextBox identitetext;
        private System.Windows.Forms.TextBox nomtext;
        private System.Windows.Forms.TextBox Mattext;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox MdpText;
        private System.Windows.Forms.TextBox loginText;
        private System.Windows.Forms.Button buttonEnregUser;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBoxMdp;
        private System.Windows.Forms.TextBox textBoxLogin;
        private System.Windows.Forms.TextBox textBoxNivHabilitation;
        private System.Windows.Forms.TextBox textBoxPrenom;
        private System.Windows.Forms.TextBox textBoxIdentite;
        private System.Windows.Forms.TextBox textBoxNom;
        private System.Windows.Forms.TextBox textBoxMatricule;
        private System.Windows.Forms.Button buttonEnregPersonnel;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxMat;
        private System.Windows.Forms.Button supprimerMat;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button AfficherDmat;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxIdPersonnel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxMemoire;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxProcesseur;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxDateAchat;
        private System.Windows.Forms.TextBox textBoxGarantie;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button enregMateriel;
        private System.Windows.Forms.TextBox textBoxFournisseur;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxDisque;
        private System.Windows.Forms.TextBox textBoxAffectation;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonEnregModifEtat;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox TextBoxTypePriseEnCharge;
        private System.Windows.Forms.TextBox textBoxetatIncident;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textIdPers2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button enregIncident;
        private System.Windows.Forms.TextBox textUtilisateur;
        private System.Windows.Forms.TextBox textTicket;
        private System.Windows.Forms.TextBox textObjet;
        private System.Windows.Forms.TextBox textPoste;
        private System.Windows.Forms.TextBox textNivUrg;
        private System.Windows.Forms.TextBox textHeure2;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBoxModifEtatDemande;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textIdMat2;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBoxTechnicienSupp;
        private System.Windows.Forms.Button buttonSupprimerTechnicien;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox formation;
        private System.Windows.Forms.TextBox Nivhabili;
        private System.Windows.Forms.TextBox nivinterv;
        private System.Windows.Forms.TextBox Prenom;
        private System.Windows.Forms.TextBox Identite;
        private System.Windows.Forms.TextBox Nom;
        private System.Windows.Forms.TextBox Matricule;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox mdp;
        private System.Windows.Forms.TextBox login;
        private System.Windows.Forms.Button button2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBoxSuppUtilisateur;
        private System.Windows.Forms.Button buttonSupprimerUtilisateur;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ComboBox comboBoxTechnicienModif;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox ModifBudgetU;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox ModifPrimeU;
        private System.Windows.Forms.TextBox ModifObjectifU;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox modifLoginU;
        private System.Windows.Forms.TextBox textBoxLoginmodifU;
        private System.Windows.Forms.Button buttonEnregistrerModifU;
        private System.Windows.Forms.ComboBox comboBoxModifUtilisateur;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button buttonEnregistrerModifT;
        private System.Windows.Forms.TextBox ModifFormation;
        private System.Windows.Forms.TextBox ModifNivInterv;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox ModifMDP;
        private System.Windows.Forms.TextBox ModifLogin;
    }
}