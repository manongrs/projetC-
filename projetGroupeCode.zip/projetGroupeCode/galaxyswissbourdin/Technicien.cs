﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class Technicien:MembreDuPersonnel
    {


        int idTechnicien;
        int nivIntervention;
        String formation;

        public Technicien(int unidPersonnel, int unMatricule, string unNom, string uneidentite, string unPrenom, int unNivhabitation, string unlogin, string unmotdePasse, int unidTechnicien, int unNivIntervention, String uneFormation)
            : base(unidPersonnel, unMatricule, unNom, uneidentite, unPrenom, unNivhabitation, unlogin, unmotdePasse)
        {
            this.idTechnicien = unidTechnicien;
            this.nivIntervention = unNivIntervention;
            this.formation = uneFormation;
        }

        public Technicien(int unMatricule, string unNom, string uneidentite, string unPrenom, int unNivhabitation, string unlogin, string unmotdePasse, int unNivIntervention, String uneFormation)
            : base(unMatricule, unNom, uneidentite, unPrenom, unNivhabitation, unlogin, unmotdePasse)
        {
            this.nivIntervention = unNivIntervention;
            this.formation = uneFormation;
        }

        public int getIdTechnicien()
        {
            return idTechnicien;
        }

        public int getNivIntervention()
        {
            return nivIntervention;
        }

        public String getFormation()
        {
            return formation;
        }


    }

}


