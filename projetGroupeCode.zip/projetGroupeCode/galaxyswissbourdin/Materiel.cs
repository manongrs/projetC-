﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class Materiel
    {
       private int idMateriel;
       private String memoire;
       private String processeur;
       private String date;
       private String garantie;
       private String fournisseurs;
       private String affectationMembrePersonnel;
       private String disque;
       int idPersonnel; /*mettre id personnel car clé étrangère, puis le mettre dans les 2 constructeurs car il n'est pas auto-incrémenter ici*/

       

        public Materiel(int unidMateriel, String uneMemoire, String unProcesseur, String uneDate, String uneGarantie, String desFournisseurs, String uneaffectationMembrePersonnel, String undisque, int unidPersonnel) { 
            this.idMateriel = unidMateriel;
            this.memoire = uneMemoire;
            this.processeur = unProcesseur;
            this.date = uneDate;
            this.garantie = uneGarantie;
            this.fournisseurs = desFournisseurs;
            this.affectationMembrePersonnel = uneaffectationMembrePersonnel;
            this.disque = undisque;
            this.idPersonnel = unidPersonnel;
           
        }

        public Materiel(String uneMemoire, String unProcesseur, String uneDate, String uneGarantie, String desFournisseurs, String uneaffectationMembrePersonnel, String undisque, int unidPersonnel)
        {
            this.memoire = uneMemoire;
            this.processeur = unProcesseur;
            this.date = uneDate;
            this.garantie = uneGarantie;
            this.fournisseurs = desFournisseurs;
            this.affectationMembrePersonnel = uneaffectationMembrePersonnel;
            this.disque = undisque;
            this.idPersonnel = unidPersonnel;
        }

        public int getIdMateriel() 
        {  
            return idMateriel; 
        }

        public String getMemoire()
        {
            return memoire;
        }

        public String getProcesseur() 
        { 
            return processeur; 
        }

        public String getDate()
        {
            return date;
        }

        public String getGarantie()
        {
            return garantie;
        }

        public String getFournisseurs()
        {
            return fournisseurs;
        }

        public String getAffectationMembrePersonnel()
        {
            return affectationMembrePersonnel;
        }

        public String getDisque()
        {
            return disque;
        }

        
        public int getIdpersonnel()
        {
            return idPersonnel;
        }
    }
}
