﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class DemandeIntervention
    {
        private int idDemande;
        private string ticketIncident;
        private string utilisateurEmeteur;
        private string objet;
        private string poste;
        private int nivUrgence;
        private int heure;
        private string Etat;
        private string Prise_En_Charge;
        private int idPersonnel;
        private int idMateriel;

        public DemandeIntervention (int unidDemande, string unticketIncident, string unutilisateurEmeteur, string unobjet, string unposte, int unnivUrgence, int uneheure, string unEtat, string unePrise,int unIdPersonnel, int unIdMateriel)
        {
            this.idDemande = unidDemande;
            this.ticketIncident = unticketIncident;
            this.utilisateurEmeteur = unutilisateurEmeteur;
            this.objet = unobjet; 
            this.poste = unposte;
            this.nivUrgence = unnivUrgence;
            this.heure = uneheure;
            this.Etat = unEtat;
            this.Prise_En_Charge = unePrise;
            this.idPersonnel = unIdPersonnel;
            this.idMateriel = unIdMateriel;
        }

        public DemandeIntervention(string unticketIncident, string unutilisateurEmeteur, string unobjet, string unposte, int unnivUrgence, int uneheure, string unEtat, string unePrise, int unIdPersonnel, int unIdMateriel)
        {
            this.ticketIncident = unticketIncident;
            this.utilisateurEmeteur = unutilisateurEmeteur;
            this.objet = unobjet;
            this.poste = unposte;
            this.nivUrgence = unnivUrgence;
            this.heure = uneheure;
            this.Etat = unEtat;
            this.Prise_En_Charge = unePrise;
            this.idPersonnel = unIdPersonnel;
            this.idMateriel = unIdMateriel;
        }

        public int getIdDemande()
        {
            return idDemande;
        }

        public string getTicketIncident()
        {
            return ticketIncident;
        }

        public string getUtilisateurEmeteur() 
        {
            return utilisateurEmeteur;
        }

        public string getObjet()
        {
            return objet;
        }

        public string getPoste() { 
            return poste; 
        }

        public int getNivurgence()
        {
            return nivUrgence;
        }

        public int getHeure()
        {
            return heure;
        }

        public string getEtat()
        {
            return Etat;
        }

        public string getPrise()
        {
            return Prise_En_Charge;
        }

        public int getIdPersonnel()
        {
            return idPersonnel;
        }

        public int getIdMateriel()
        {
            return idMateriel;
        }
    }
}
