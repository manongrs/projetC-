﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class Logiciels
    {
       private int idLogiciel;
       private String nomLogiciel;
       private String Description; 

        public Logiciels (int unidLogiciel, string unnomLogiciel, string uneDescription)
        {
            this.idLogiciel = unidLogiciel;
            this.nomLogiciel = unnomLogiciel;
            this.Description = uneDescription;
        }

        public Logiciels (string unnomLogiciel, string uneDescription)
        {
            this.nomLogiciel=unnomLogiciel;
            this.Description = uneDescription;
        }

        public int getIdLogiciel ()
        {
            return idLogiciel;
        }

        public String getNomLogiciel ()
        {
            return nomLogiciel;
        }

        public String getDescription()
        {
            return Description;
        }
    }
}
