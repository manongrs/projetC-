﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class Utilisateurs:MembreDuPersonnel
    {
        int idVisiteurs;
        string objectif;
        int prime;
        int budget;

        public Utilisateurs(int unidPersonnel, int unMatricule, string unNom, string uneidentite, string unPrenom, int unNivhabitation, string unlogin, string unmotdePasse, int unidVisiteurs, string unobjectifs, int uneprime, int unbudget)
            : base(unidPersonnel, unMatricule, unNom, uneidentite, unPrenom, unNivhabitation, unlogin, unmotdePasse)
        {
            this.idVisiteurs = unidVisiteurs;
            this.objectif = unobjectifs;
            this.prime = uneprime;
            this.budget = unbudget;
        }

        public Utilisateurs(int unMatricule, string unNom, string uneidentite, string unPrenom, int unNivhabitation, string unlogin, string unmotdePasse, string unobjectifs, int uneprime, int unbudget)
            : base(unMatricule, unNom, uneidentite, unPrenom, unNivhabitation, unlogin, unmotdePasse)
        {
            this.objectif = unobjectifs;
            this.prime = uneprime;
            this.budget = unbudget;
        }

        public int getIdVisiteurs()
        {
            return idVisiteurs;
        }

        public string getObjectif()
        {
            return objectif;
        }

        public int getPrime()
        {
            return prime;
        }

        public int getBudget()
        {
            return budget;
        }


    }
}
