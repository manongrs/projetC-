﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class competence
    {
        int idCompetence;
        string descriptionCompetence;

        public competence(int unidCompetence, string unedescriptionCompetence)
        {
            this.idCompetence = unidCompetence;
            this.descriptionCompetence = unedescriptionCompetence;
        }

        public competence(string unedescriptionCompetence)
        {
            this.descriptionCompetence = unedescriptionCompetence;
        }

        public int getIdCompetence()
        {
            return idCompetence;
        }

        public string getDescriptionCompetence()
        {
            return descriptionCompetence;
        }
    }
}
