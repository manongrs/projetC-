﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class MembreDuPersonnel
    {
        // Déclaration des champs privés (variables membres de la classe)
        private int idPersonnel;            // ID du personnel
        private int Matricule;              // Numéro de matricule
        private string Nom;                 // Nom du membre du personnel
        private string identite;            // Identité (peut-être une description)
        
        private string prenom;              // Prénom du membre du personnel
        private int nivhabilitation;        // Niveau d'habilitation
        private string login;               // Nom d'utilisateur
        private string motdepasse;          // Mot de passe


        // 
        public MembreDuPersonnel(int unidPersonnel, int unMatricule, string unNom, string uneidentite, string unPrenom, int unNivhabilitation, string unlogin, string unmotdePasse)
        {
            this.idPersonnel = unidPersonnel;
            this.Matricule = unMatricule;
            this.Nom = unNom;
            this.identite = uneidentite;
       
            this.prenom = unPrenom;
            this.nivhabilitation = unNivhabilitation;
            this.login = unlogin;
            this.motdepasse = unmotdePasse;
        }

        public MembreDuPersonnel(int unMatricule, string unNom, string uneidentite, string unPrenom, int unNivhabilitation, string unlogin, string unmotdePasse)
        {

            this.Matricule = unMatricule;
            this.Nom = unNom;
            this.identite = uneidentite;
            
            this.prenom = unPrenom;
            this.nivhabilitation = unNivhabilitation;
            this.login = unlogin;
            this.motdepasse = unmotdePasse;
        }

        public int getIdPersonnel()
        {
            return idPersonnel;
        }

        public int getMatricule()
        {
            return Matricule;
        }

        public string getNom()
        {
            return Nom;
        }

        public string getIdentite()
        {
            return identite;
        }

        

        public string getPrenom()
        {
            return prenom;
        }

        public int getnivhabilitation()
        {
            return nivhabilitation;
        }

        public string getLogin()
        {
            return login;
        }

        public string getMotdepasse()
        {
            return motdepasse;
        }

    }
}
