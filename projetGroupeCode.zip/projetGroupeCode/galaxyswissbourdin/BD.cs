﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;



namespace galaxyswissbourdin
{
    public class BD

    {



        


        public static void insertMembreDuPersonnel(MembreDuPersonnel unMembreDuPersonnel)
        {
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "insert into membre_du_personnel(Matricule, Nom, identite, Prenom, niveau_d_habilitation, login, mot_de_passe) values (@Matricule, @Nom, @identite, @Prenom, @niveau_d_habilitation, @login, @mot_de_passe)";
            cmd.Parameters.AddWithValue("@Matricule", unMembreDuPersonnel.getMatricule());
            cmd.Parameters.AddWithValue("@Nom", unMembreDuPersonnel.getNom());
            cmd.Parameters.AddWithValue("@identite", unMembreDuPersonnel.getIdentite());
            cmd.Parameters.AddWithValue("@Prenom", unMembreDuPersonnel.getPrenom());
            cmd.Parameters.AddWithValue("@niveau_d_habilitation", unMembreDuPersonnel.getnivhabilitation());
            cmd.Parameters.AddWithValue("@login", unMembreDuPersonnel.getLogin());
            cmd.Parameters.AddWithValue("@mot_de_passe", unMembreDuPersonnel.getMotdepasse());
            cmd.ExecuteNonQuery();
            conn.Close();
        }





        public static void insertTechnicien(Technicien unTechnicien)
        {
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "insert into membre_du_personnel(Matricule, Nom, identite, Prenom, niveau_d_habilitation, login, mot_de_passe) values (@Matricule, @Nom, @identite, @Prenom, @niveau_d_habilitation, @login, @mot_de_passe)";
            cmd.Parameters.AddWithValue("@Matricule", unTechnicien.getMatricule());
            cmd.Parameters.AddWithValue("@Nom", unTechnicien.getNom());
            cmd.Parameters.AddWithValue("@identite", unTechnicien.getIdentite());
            cmd.Parameters.AddWithValue("@Prenom", unTechnicien.getPrenom());
            cmd.Parameters.AddWithValue("@niveau_d_habilitation", unTechnicien.getnivhabilitation());
            cmd.Parameters.AddWithValue("@login", unTechnicien.getLogin());
            cmd.Parameters.AddWithValue("@mot_de_passe", unTechnicien.getMotdepasse());
            cmd.ExecuteNonQuery();

            MySqlCommand cmd2 = conn.CreateCommand();
            cmd2.CommandText = "SELECT MAX(id_personnel) from membre_du_personnel";
            int id = Convert.ToInt16(cmd2.ExecuteScalar());
            cmd.ExecuteNonQuery();

            MySqlCommand cmd3 = conn.CreateCommand();
            cmd3.CommandText = "insert into technicien(id_personnel, niveau_Intervention, Formation) values (@id_personnel, @niveau_Intervention, @Formation)";
            cmd3.Parameters.AddWithValue("@id_personnel", id);
            cmd3.Parameters.AddWithValue("@niveau_Intervention", unTechnicien.getNivIntervention());
            cmd3.Parameters.AddWithValue("@Formation", unTechnicien.getFormation());
            cmd3.ExecuteNonQuery();
            conn.Close();
        }

        public static void insertUtilisateurs(Utilisateurs unUtilisateur)
        {
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "insert into membre_du_personnel(Matricule, Nom, identite, Prenom, niveau_d_habilitation, login, mot_de_passe) values (@Matricule, @Nom, @identite, @Prenom, @niveau_d_habilitation, @login, @mot_de_passe)";
            cmd.Parameters.AddWithValue("@Matricule", unUtilisateur.getMatricule());
            cmd.Parameters.AddWithValue("@Nom", unUtilisateur.getNom());
            cmd.Parameters.AddWithValue("@identite", unUtilisateur.getIdentite());
            cmd.Parameters.AddWithValue("@Prenom", unUtilisateur.getPrenom());
            cmd.Parameters.AddWithValue("@niveau_d_habilitation", unUtilisateur.getnivhabilitation());
            cmd.Parameters.AddWithValue("@login", unUtilisateur.getLogin());
            cmd.Parameters.AddWithValue("@mot_de_passe", unUtilisateur.getMotdepasse());
            cmd.ExecuteNonQuery();

            MySqlCommand cmd2 = conn.CreateCommand();
            cmd2.CommandText = "SELECT MAX(id_personnel) from membre_du_personnel";
            int id = Convert.ToInt16(cmd2.ExecuteScalar());
            cmd.ExecuteNonQuery();

            MySqlCommand cmd3 = conn.CreateCommand();
            cmd3.CommandText = "insert into utilisateurs(id_personnel, objectif, prime, Budget) values (@id_personnel, @objectif, @prime, @Budget)";
            cmd3.Parameters.AddWithValue("@id_personnel", id);
            cmd3.Parameters.AddWithValue("@objectif", unUtilisateur.getObjectif());
            cmd3.Parameters.AddWithValue("@prime", unUtilisateur.getPrime());
            cmd3.Parameters.AddWithValue("@budget", unUtilisateur.getBudget());
            cmd3.ExecuteNonQuery();
            conn.Close();
        }




        




        public static void insertMateriel(Materiel unMateriel)
        {
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "insert into materiel(memoire, Processeur, date_achats, garantie, fournisseurs, affectation_membre_personnel,Disque, id_personnel) values (@memoire, @Processeur, @date_achats, @garantie, @fournisseurs, @affectation_membre_personnel,@Disque, @id_personnel )";
            cmd.Parameters.AddWithValue("@memoire", unMateriel.getMemoire());
            cmd.Parameters.AddWithValue("@Processeur", unMateriel.getProcesseur());
            cmd.Parameters.AddWithValue("@date_achats", unMateriel.getDate());
            cmd.Parameters.AddWithValue("@garantie", unMateriel.getGarantie());
            cmd.Parameters.AddWithValue("@fournisseurs", unMateriel.getFournisseurs());
            cmd.Parameters.AddWithValue("@affectation_membre_personnel", unMateriel.getAffectationMembrePersonnel());
            cmd.Parameters.AddWithValue("@Disque", unMateriel.getDisque());
            cmd.Parameters.AddWithValue("@id_personnel", unMateriel.getIdpersonnel());

            cmd.ExecuteNonQuery();
            conn.Close();
        }


        
        public static void insertIncident(DemandeIntervention uneDemandeIntervention)
        {
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd4 = conn.CreateCommand();
            cmd4.CommandText = "insert into demande_intervention(ticket_Incident, Utilisateur, Objet, Poste, Niveau_urgence, heure, Etat, Prise_En_Charge,id_personnel, id_materiel) values (@ticket_Incident, @Utilisateur, @Objet, @Poste, @Niveau_urgence, @heure, @Etat, @Prise_En_Charge, @id_personnel, @id_materiel)";
            MySqlParameterCollection parameters = cmd4.Parameters;
            parameters.AddWithValue("@ticket_Incident", uneDemandeIntervention.getTicketIncident());
            cmd4.Parameters.AddWithValue("@Utilisateur", uneDemandeIntervention.getUtilisateurEmeteur());
            cmd4.Parameters.AddWithValue("@Objet", uneDemandeIntervention.getObjet());
            cmd4.Parameters.AddWithValue("@Poste", uneDemandeIntervention.getPoste());
            cmd4.Parameters.AddWithValue("@Niveau_urgence", uneDemandeIntervention.getNivurgence());
            cmd4.Parameters.AddWithValue("@heure", uneDemandeIntervention.getHeure());
            cmd4.Parameters.AddWithValue("@Etat", uneDemandeIntervention.getEtat());
            cmd4.Parameters.AddWithValue("@Prise_En_Charge", uneDemandeIntervention.getPrise());
            cmd4.Parameters.AddWithValue("@id_personnel", uneDemandeIntervention.getIdPersonnel());
            cmd4.Parameters.AddWithValue("@id_materiel", uneDemandeIntervention.getIdMateriel());

            cmd4.ExecuteNonQuery();
            conn.Close();

        } 


        public static List<Materiel> SelectionnerMateriel()
        {
            List<Materiel> lesmateriels = new List<Materiel>();
            Materiel unMateriel;
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * from materiel";
            MySqlDataReader dataReader = cmd.ExecuteReader();
            while (dataReader.Read())
            {
                unMateriel = new Materiel(Convert.ToInt16(dataReader["id_materiel"]), Convert.ToString(dataReader["memoire"]), Convert.ToString(dataReader["Processeur"]), Convert.ToString(dataReader["date_achats"]), Convert.ToString(dataReader["garantie"]), Convert.ToString(dataReader["fournisseurs"]), Convert.ToString(dataReader["affectation_membre_personnel"]), Convert.ToString(dataReader["Disque"]), Convert.ToInt16(dataReader["id_personnel"]));
                lesmateriels.Add(unMateriel);
            }
            conn.Close();
            return lesmateriels;
        }

        //Fonction qui supprime un matériel à partir de son id0.
        public static void supprimerMateriel(Materiel unMateriel)
        {
            string connString = "Server=127.0.0.1;Database=intervention;Uid=root;Password=;SslMode=none";
            MySqlConnection conn;
            conn = new MySqlConnection(connString);
            conn.Open();
            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM materiel WHERE id_materiel= @id_materiel";
            cmd.Parameters.AddWithValue("@id_materiel", unMateriel.getIdMateriel());
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        
    }
}