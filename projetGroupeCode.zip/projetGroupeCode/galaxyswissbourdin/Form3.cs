﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace galaxyswissbourdin
{
    public partial class Form3 : Form
    {
        

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            lesmateriels = BD.SelectionnerMateriel();
            foreach (Materiel unmateriel in lesmateriels)
            {
                comboBoxMat.Items.Add(unmateriel.getGarantie());
            }
        }
        
        List<Materiel> lesmateriels = new List<Materiel>();


        private void enregMateriel_Click(object sender, EventArgs e)
        {
            Materiel unMateriel = new Materiel(textBoxMemoire.Text, textBoxProcesseur.Text, textBoxDateAchat.Text, textBoxGarantie.Text, textBoxFournisseur.Text, textBoxAffectation.Text, textBoxDisque.Text, Convert.ToInt16(textBoxIdPersonnel.Text));
            BD.insertMateriel(unMateriel);
        }

        private void buttonEnregPersonnel_Click(object sender, EventArgs e)
        {
            MembreDuPersonnel unmembreDuPersonnel = new MembreDuPersonnel(Convert.ToInt16(textBoxMatricule.Text), textBoxNom.Text, textBoxIdentite.Text, textBoxPrenom.Text, Convert.ToInt16(textBoxNivHabilitation.Text), textBoxLogin.Text, textBoxMdp.Text);
            BD.insertMembreDuPersonnel(unmembreDuPersonnel);

        }

        private void buttonEnregTechnicien_Click(object sender, EventArgs e)
        {
            Technicien unTechnicien = new Technicien(Convert.ToInt16(Matricule.Text), Nom.Text, Identite.Text, Prenom.Text, Convert.ToInt16(Nivhabili.Text), login.Text, mdp.Text, Convert.ToInt16(nivinterv.Text), formation.Text);
            BD.insertTechnicien(unTechnicien);

        }





        private void supprimerMat_Click(object sender, EventArgs e)
        {
           
            int rangSelect = comboBoxMat.SelectedIndex;
            lesmateriels = BD.SelectionnerMateriel();
            BD.supprimerMateriel(lesmateriels[rangSelect]);
        }



        /* enregistrer un incident et enregister un utilisateur ne marche pas*/
        private void enregIncident_Click(object sender, EventArgs e)
        {
            DemandeIntervention uneDemandeIntervention = new DemandeIntervention(textTicket.Text, textUtilisateur.Text, textObjet.Text, textPoste.Text, Convert.ToInt16(textNivUrg.Text), Convert.ToInt16(textHeure2.Text), textBoxetatIncident.Text, TextBoxTypePriseEnCharge.Text,Convert.ToInt16(textIdPers2.Text), Convert.ToInt16(textIdMat2.Text));
            BD.insertIncident(uneDemandeIntervention);
        }

        private void buttonEnregUser_Click(object sender, EventArgs e)
        {
            Utilisateurs unUtilisateur = new Utilisateurs(Convert.ToInt16(Mattext.Text), nomtext.Text, identitetext.Text, prenomtext.Text, Convert.ToInt16(nivText.Text), loginText.Text, MdpText.Text, objtext.Text, Convert.ToInt16(primetext.Text), Convert.ToInt16(budgettext.Text));
            BD.insertUtilisateurs(unUtilisateur);

        }


    }
}
