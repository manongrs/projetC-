﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace galaxyswissbourdin
{
    public class Region
    {
        int idRegion;
        string nomRegion;

        public Region(int unidRegion, string unnomRegion)
        {
            this.idRegion = unidRegion;
            this.nomRegion = unnomRegion;
        }

        public Region(string unnomRegion)
        {
            this.nomRegion = unnomRegion;
        }

        public int getIdRegion ()
        {  
            return idRegion;  
        }

        public string getNomRegion ()
        {
            return nomRegion;
        }
    }
}
